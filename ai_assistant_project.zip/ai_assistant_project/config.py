import requests
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()
api_key = os.getenv("AIzaSyCrkjQQFJv_OL8m08lN6uRva9HDk2KYtko")
project_id = "Gemini API"

# Example endpoint (modify as per valid OpenAI endpoints)
url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash-latest:generateContent?key=AIzaSyCrkjQQFJv_OL8m08lN6uRva9HDk2KYtko"

# Set up headers
headers = {
    "Authorization": f"Bearer {api_key}"
}

# Make the request
response = requests.get(url, headers=headers)

# Handle the response
if response.status_code == 200:
    project_info = response.json()
    print("Project Information:", project_info)
else:
    print(f"Failed to retrieve project info. Status Code: {response.status_code}")
    print("Error:", response.json())

