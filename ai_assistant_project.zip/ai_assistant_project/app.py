import os
import requests
from flask import Flask, request, render_template, send_file
from dotenv import load_dotenv
from reportlab.pdfgen import canvas
from io import BytesIO
from docx import Document

# Load environment variables
load_dotenv()
api_key = os.getenv("AIzaSyCrkjQQFJv_OL8m08lN6uRva9HDk2KYtko")

app = Flask(__name__)

@app.route("/")
def index():
    return render_template("index.html")

# Text generation endpoint using Gemini API
@app.route("/generate-text", methods=["POST"])
def generate_text():
    prompt = request.form.get("prompt")
    url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash-latest:generateText?key={AIzaSyCrkjQQFJv_OL8m08lN6uRva9HDk2KYtko}"
    
    payload = {
        "prompt": prompt,
        "max_tokens": 100
    }
    
    headers = {
        "Content-Type": "application/json"
    }
    
    response = requests.post(url, headers=headers, json=payload)
    
    if response.status_code == 200:
        result = response.json()
        generated_text = result.get("text", "No response")
        return generated_text
    else:
        return f"Error: {response.status_code} - {response.json()}"

# Image generation endpoint (Adjust if Gemini supports image generation)
@app.route("/generate-image", methods=["POST"])
def generate_image():
    prompt = request.form.get("prompt")
    url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash-latest:generateImage?key={api_key}"  # Adjust URL if necessary
    
    payload = {
        "prompt": prompt,
        "size": "512x512"
    }
    
    headers = {
        "Content-Type": "application/json"
    }
    
    response = requests.post(url, headers=headers, json=payload)
    
    if response.status_code == 200:
        result = response.json()
        image_url = result['data'][0]['url']
        return image_url
    else:
        return f"Error: {response.status_code} - {response.json()}"

# PDF generation endpoint
@app.route("/generate-pdf", methods=["POST"])
def generate_pdf():
    content = request.form.get("content")
    pdf_buffer = BytesIO()
    p = canvas.Canvas(pdf_buffer)
    p.drawString(100, 750, content)
    p.showPage()
    p.save()
    pdf_buffer.seek(0)
    return send_file(pdf_buffer, as_attachment=True, download_name="generated.pdf", mimetype="application/pdf")

# Word document generation endpoint
@app.route("/generate-docx", methods=["POST"])
def generate_docx():
    content = request.form.get("content")
    doc = Document()
    doc.add_paragraph(content)
    doc_buffer = BytesIO()
    doc.save(doc_buffer)
    doc_buffer.seek(0)
    return send_file(doc_buffer, as_attachment=True, download_name="generated.docx", mimetype="application/vnd.openxmlformats-officedocument.wordprocessingml.document")

if __name__ == "__main__":
    app.run(debug=True)
